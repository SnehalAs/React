import './index.css'

const NotFound = () =>{

    return(
        <div className='not-found-cont'>
         <h1>The Path You Have Entered In The URL Is Wrong Please Correct It!!!</h1>
        </div>
    )
}

export default NotFound;